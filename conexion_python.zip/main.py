import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
from conexion import Connection
import Pacientes_sql as sql
import pandas as pd

external_stylesheets = ["https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"]


# INICIALIZACION DE CONNECTION
con = Connection()

# Consulta de todas las tablas
con.openConnection()
querydiagnostico = pd.read_sql_query(sql.total_diagnosticos(), con.connection)
querypacientes = pd.read_sql_query(sql.total_pacientes(), con.connection)
queryregistromed = pd.read_sql_query(sql.total_registro_med(), con.connection)
queryidtipomed = pd.read_sql_query(sql.total_id_tipo_med(), con.connection)
con.closeConnection()

#Crea el dataframe
DFdiagnostico = pd.DataFrame(querydiagnostico, columns=["Numero_de_caso", "diagnostico", "id_tipomed_id_tipo_med"])
DFregistromed = pd.DataFrame(queryregistromed, columns=["id_med", "Nombre_generico", "Descripcion", "Cantidad", "presentacion", "stock", "id_tipomed_id_tipo_med"])
DFpacientes = pd.DataFrame(querypacientes, columns=["ID_CC", "Sexo", "edad", "Mes", "Servicio", "Estancia", "Tercero", "año", "Numero_de_caso"])
DFidtipomed = pd.DataFrame(queryidtipomed, columns=["id_tipomed", "tipo_medicamento"])

#main
if __name__ == '__main__':
    #app.run_server(debug=True)
    print(DFdiagnostico)
    print("---------------")
    print(DFregistromed)
    print("---------------")
    print(DFpacientes)
    print("---------------")
    print(DFidtipomed)


