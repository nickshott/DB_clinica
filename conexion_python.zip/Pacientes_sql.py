
def total_diagnosticos():
    return '''select * from "Diagnostico" order by "Numero_de_caso" ASC'''

def total_pacientes():
    return '''select * from "Pacientes" order by "ID_CC" ASC'''

def total_registro_med():
    return '''select * from "Registro_med" order by "id_med" ASC'''

def total_id_tipo_med():
    return '''select * from "id_tipo_med" order by "id_tipomed" ASC'''